using Microsoft.EntityFrameworkCore;
using ComputerStore.Models;

namespace ComputerStore.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        public DbSet<CartItem> CartItems { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure relationships
            modelBuilder.Entity<Order>()
                .HasOne(o => o.User)
                .WithMany(u => u.Orders)
                .HasForeignKey(o => o.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<OrderItem>()
                .HasOne(oi => oi.Order)
                .WithMany(o => o.OrderItems)
                .HasForeignKey(oi => oi.OrderId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<OrderItem>()
                .HasOne(oi => oi.Product)
                .WithMany(p => p.OrderItems)
                .HasForeignKey(oi => oi.ProductId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<CartItem>()
                .HasOne(ci => ci.User)
                .WithMany(u => u.CartItems)
                .HasForeignKey(ci => ci.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<CartItem>()
                .HasOne(ci => ci.Product)
                .WithMany(p => p.CartItems)
                .HasForeignKey(ci => ci.ProductId)
                .OnDelete(DeleteBehavior.Cascade);

            // Seed data
            SeedData(modelBuilder);
        }

        private void SeedData(ModelBuilder modelBuilder)
        {
            // Seed Products
            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    Id = 1,
                    Name = "Laptop Dell Inspiron 15",
                    Description = "Laptop Dell Inspiron 15 inch, Intel Core i5, 8GB RAM, 256GB SSD",
                    Price = 15990000,
                    StockQuantity = 10,
                    Brand = "Dell",
                    Category = "Laptop",
                    ImageUrl = "/images/dell-inspiron-15.jpg",
                    IsAvailable = true,
                    CreatedAt = new DateTime(2024, 1, 1),
                    UpdatedAt = new DateTime(2024, 1, 1)
                },
                new Product
                {
                    Id = 2,
                    Name = "Laptop HP Pavilion 14",
                    Description = "Laptop HP Pavilion 14 inch, AMD Ryzen 5, 8GB RAM, 512GB SSD",
                    Price = 17990000,
                    StockQuantity = 8,
                    Brand = "HP",
                    Category = "Laptop",
                    ImageUrl = "/images/hp-pavilion-14.jpg",
                    IsAvailable = true,
                    CreatedAt = new DateTime(2024, 1, 1),
                    UpdatedAt = new DateTime(2024, 1, 1)
                },
                new Product
                {
                    Id = 3,
                    Name = "PC Gaming MSI",
                    Description = "PC Gaming MSI, Intel Core i7, 16GB RAM, RTX 3060, 1TB SSD",
                    Price = 25990000,
                    StockQuantity = 5,
                    Brand = "MSI",
                    Category = "Desktop",
                    ImageUrl = "/images/msi-gaming-pc.jpg",
                    IsAvailable = true,
                    CreatedAt = new DateTime(2024, 1, 1),
                    UpdatedAt = new DateTime(2024, 1, 1)
                },
                new Product
                {
                    Id = 4,
                    Name = "MacBook Air M1",
                    Description = "MacBook Air với chip M1, 8GB RAM, 256GB SSD",
                    Price = 29990000,
                    StockQuantity = 6,
                    Brand = "Apple",
                    Category = "Laptop",
                    ImageUrl = "/images/macbook-air-m1.jpg",
                    IsAvailable = true,
                    CreatedAt = new DateTime(2024, 1, 1),
                    UpdatedAt = new DateTime(2024, 1, 1)
                },
                new Product
                {
                    Id = 5,
                    Name = "Chuột Gaming Logitech G502",
                    Description = "Chuột gaming Logitech G502 HERO với cảm biến 25K DPI",
                    Price = 890000,
                    StockQuantity = 20,
                    Brand = "Logitech",
                    Category = "Accessories",
                    ImageUrl = "/images/logitech-g502.jpg",
                    IsAvailable = true,
                    CreatedAt = new DateTime(2024, 1, 1),
                    UpdatedAt = new DateTime(2024, 1, 1)
                }
            );

            // Seed Admin User
            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    Username = "admin",
                    Email = "admin@computerstore.com",
                    PasswordHash = "admin123", // In production, use proper password hashing
                    FirstName = "Admin",
                    LastName = "User",
                    Phone = "0123456789",
                    Address = "123 Admin Street, Hanoi",
                    IsAdmin = true,
                    CreatedAt = new DateTime(2024, 1, 1),
                    LastLogin = new DateTime(2024, 1, 1)
                }
            );
        }
    }
}

