using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ComputerStore.Models;
using ComputerStore.Data;

namespace ComputerStore.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly ApplicationDbContext _context;

    public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
    {
        _logger = logger;
        _context = context;
    }

    public async Task<IActionResult> Index(string searchString, string category, string brand)
    {
        var products = from p in _context.Products
                      select p;

        if (!string.IsNullOrEmpty(searchString))
        {
            products = products.Where(p => p.Name.Contains(searchString) || p.Description.Contains(searchString));
        }

        if (!string.IsNullOrEmpty(category))
        {
            products = products.Where(p => p.Category == category);
        }

        if (!string.IsNullOrEmpty(brand))
        {
            products = products.Where(p => p.Brand == brand);
        }

        var categories = await _context.Products.Select(p => p.Category).Distinct().ToListAsync();
        var brands = await _context.Products.Select(p => p.Brand).Distinct().ToListAsync();

        ViewBag.Categories = categories;
        ViewBag.Brands = brands;
        ViewBag.SearchString = searchString;
        ViewBag.SelectedCategory = category;
        ViewBag.SelectedBrand = brand;

        return View(await products.ToListAsync());
    }

    public async Task<IActionResult> ProductDetail(int id)
    {
        var product = await _context.Products.FirstOrDefaultAsync(p => p.Id == id);
        if (product == null)
        {
            return NotFound();
        }

        return View(product);
    }

    [Microsoft.AspNetCore.Authorization.AllowAnonymous]
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
